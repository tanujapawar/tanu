package spring.cdac.studentenquiry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentEnquiryApplicationTests {

	@Test
	void contextLoads() {
	}

}
