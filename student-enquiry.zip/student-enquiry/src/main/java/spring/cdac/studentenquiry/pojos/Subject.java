package spring.cdac.studentenquiry.pojos;



import javax.persistence.*;

@Entity
@Table(name="subjects")
public class Subject {
	private String subId;
	private String subName,courseId;

	public Subject() {
		super();
		
	}

	
	public Subject(String subId, String subName, String courseId) {
		super();
		this.subId = subId;
		this.subName = subName;
		this.courseId = courseId;
	}


	@Id
	@Column(length = 10,unique = true,nullable = false)
	public String getSubId() {
		return subId;
	}

	public void setSubId(String subId) {
		this.subId = subId;
	}

	@Column(length = 20)
	public String getSubName() {
		return subName;
	}

	public void setSubName(String subName) {
		this.subName = subName;
	}

	@Column(length = 10)
	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	
	

	@Override
	public String toString() {
		return "Subjects [subId=" + subId + ", subName=" + subName + ", courseId=" + courseId + "]";
	}
	
	
	
}
	