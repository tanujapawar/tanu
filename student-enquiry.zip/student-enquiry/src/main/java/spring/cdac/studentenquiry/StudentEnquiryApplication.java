package spring.cdac.studentenquiry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentEnquiryApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentEnquiryApplication.class, args);
	}

}
