package spring.cdac.studentenquiry.pojos;

import java.util.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "enquiry")
public class Enquiry {
	private Integer enquiryId;
	private String crsForEnq,username,email,contact,question;
	private Date dateOfEnq;
	
	
	public Enquiry() {
		super();
		
	}

	public Enquiry(String crsForEnq, String username, String email, String contact, String question, Date dateOfEnq) {
		super();
		this.crsForEnq = crsForEnq;
		this.username = username;
		this.email = email;
		this.contact = contact;
		this.question = question;
		this.dateOfEnq = dateOfEnq;
	}
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(Integer enquiryId) {
		this.enquiryId = enquiryId;
	}

	@Column(length = 10 )//fk
	public String getCrsForEnq() {
		return crsForEnq;
	}

	public void setCrsForEnq(String crsForEnq) {
		this.crsForEnq = crsForEnq;
	}

	@Column(length = 20)
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(length = 20,unique = true,nullable = false)
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(length = 12,unique = true,nullable = false)
	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	@Column(length = 200)
	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	@DateTimeFormat()
	public Date getDateOfEnq() {
		return dateOfEnq;
	}

	public void setDateOfEnq(Date dateOfEnq) {
		this.dateOfEnq = dateOfEnq;
	}

	
	@Override
	public String toString() {
		return "Enquiry [enquiryId=" + enquiryId + ", crsForEnq=" + crsForEnq + ", username=" + username + ", email="
				+ email + ", contact=" + contact + ", question=" + question + ", dateOfEnq=" + dateOfEnq + "]";
	}
	
	
	
	
}
