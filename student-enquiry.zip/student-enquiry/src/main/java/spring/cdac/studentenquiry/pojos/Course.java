package spring.cdac.studentenquiry.pojos;

//import java.util.ArrayList;
//import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "courses")
public class Course {
	private String courseId;
	private String courseName,duration,eligibility;
	private double fees;
	private int seats;
	//private List<Subjects> sub=new ArrayList<>();
	
	public Course() {
		super();
		
	}

	

	public Course(String courseId, String courseName, String duration, String eligibility, double fees, int seats) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.duration = duration;
		this.eligibility = eligibility;
		this.fees = fees;
		this.seats = seats;
	}



	@Id
	@Column(length=10,unique = true,nullable=false)
	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	
	@Column(length = 10)
	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	@Column(length = 30)
	public String getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration = duration;
	}

	@Column(length = 30)
	public String getEligibility() {
		return eligibility;
	}

	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	
	public double getFees() {
		return fees;
	}

	public void setFees(double fees) {
		this.fees = fees;
	}

	public int getSeats() {
		return seats;
	}

	public void setSeats(int seats) {
		this.seats = seats;
	}


	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + ", duration=" + duration
				+ ", eligibility=" + eligibility + ", fees=" + fees + ", seats=" + seats + "]";
	}
	
	
	
	
}
