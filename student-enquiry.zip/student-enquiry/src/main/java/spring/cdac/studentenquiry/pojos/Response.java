package spring.cdac.studentenquiry.pojos;

import java.util.Date;

import javax.persistence.*;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="response")
public class Response {
	private Integer respId;
	private int enquiryId;
	private String asgnTo;
	private Date date;
	
	
	public Response() {
		super();	
	}

	public Response(int enquiryId, String asgnTo, Date date) {
		super();
		this.enquiryId = enquiryId;
		this.asgnTo = asgnTo;
		this.date = date;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getRespId() {
		return respId;
	}

	public void setRespId(Integer respId) {
		this.respId = respId;
	}

	public int getEnquiryId() {
		return enquiryId;
	}

	public void setEnquiryId(int enquiryId) {
		this.enquiryId = enquiryId;
	}

	
	public String getAsgnTo() {
		return asgnTo;
	}

	public void setAsgnTo(String asgnTo) {
		this.asgnTo = asgnTo;
	}

	@DateTimeFormat(pattern = "dd-MM-yyyy")
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}


	@Override
	public String toString() {
		return "Responses [respId=" + respId + ", enquiryId=" + enquiryId + ", asgnTo=" + asgnTo + ", date=" + date
				+  "]";
	}
	
	
	
	
	
}
